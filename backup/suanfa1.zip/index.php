<?php
$text = "Apple,20,Red,Pear,10,Yellow";
$columnNames = array('Fruit', 'Number', 'Color');


function ExplodeLines($text, $columnNames){
	$rValue = array();

	$aText = explode(',', $text);

	$cLen = count($columnNames);

	$arr = array();
	$index = 0;
	foreach($aText as $k1 => $v1){
		$index = $k1%$cLen;
		$arr[$columnNames[$index]] = $v1;
		if(($cLen - 1) == $index)
			$rValue[] = $arr;
	}
	return $rValue;
}

$file = dirname(__FILE__).'/test.txt';
$handle = fopen($file, 'r');
if($handle){
	while(!feof($handle)){
		$text = fgets($handle, 4096);
		$arr = ExplodeLines($text, $columnNames);
		var_dump($arr);
	}
}


